<!DOCTYPE html>
<html>
<head>
	<title>login success</title>
</head>
<body background="img/authorized.jpg">
<?php
$usr=$_POST['usr'];
$pwd=$_POST['pwd'];
if ($usr == "admin" && $pwd === "admin") {
    echo "correct credential...<br>";
} else {
    echo "Authentication error :(<br>";
    window.location("login.php?error=faied");
}
?>
</body>
</html> 
