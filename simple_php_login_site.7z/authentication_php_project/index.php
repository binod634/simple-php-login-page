<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="./index.css">
    <!-- <script type="text/javascript" src="index.js"> --!>
	<title>Login</title>
</head>
<body background="img/bg.png">
<form action="index.php" method="POST">
	<table border="2">
		<tr>
			<td>
				Username:
			</td>
			<td>
				<input type="text" name="usr" required>
			</td>
		</tr>
		<tr>
			<td>
				Password:
			</td>
			<td>
				<input type="password" name="pwd" required>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="submit" name="sub" value="Login">
			</td>
		</tr>
		<tr>
		<td colspan="2">
		    <?php 
		    // running php
		    if (!isset($_COOKIE['PHPSESSIONID'])) {
		        $characters="abcdefghijklmnopqrstuvwxyz0123456789";
		        $random="hello";
		        for ($i = 1; $i <= 12; $i ++ ) {                           // directly defining $i on loop... but okey :)
		            $randint  = rand(0,strlen($characters)-1);
		            $random  = $random.$characters[$randint];
		        }                                                       // at least the function is working correctly without error...
		        setcookie("PHPSESSIONID",$random,time()+(600));
		    }
		    if (isset($_POST['usr']) && isset($_POST['pwd'])) {
		        $usr = $_POST['usr'];
		        $pwd = $_POST['pwd'];
		        if ($usr == "admin" && $pwd == "admin" ) {            # change if necessary...
		            $fobj = fopen("authenticated","w");
		            fwrite($fobj,$_COOKIE['PHPSESSIONID']);
		            fclose($fobj);
		            header("Location:welcome.php");
		        } else {
		            echo "<p style=\"color:red;font-weight:bold\"> Authentication error !!! </p>";
		        }
		    }                                                        # end of php and starting all that html shit... :(
		    ?>
		</td>
		</tr>
	</table>
</form>
</body>
</html>
